export async function handler(event) {
  const address = event.queryStringParameters.address;

  if (!address) {
    return {
      statusCode: 400,
      body: JSON.stringify({ error: "No address provided" })
    };
  }

  const url = `https://testnet.arcscan.app/api
    ?module=account
    &action=txlist
    &address=${address}
    &page=1
    &offset=1000
    &sort=asc`;

  try {
    const response = await fetch(url);
    const data = await response.json();

    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*"
      },
      body: JSON.stringify(data)
    };
  } catch (err) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "ArcScan fetch failed" })
    };
  }
}